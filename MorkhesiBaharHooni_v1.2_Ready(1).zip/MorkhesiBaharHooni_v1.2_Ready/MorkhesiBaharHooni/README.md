# مرخصی بهار هونی — نسخه 1.2 (آماده Build)

اپ اندروید (Kotlin + Jetpack Compose) با Firebase Authentication و Firestore و Storage.

## تغییرات نسخه 1.2 نسبت به 1.1
- رفع خطاهای Build (تم Manifest، وابستگی coroutines، تابع statusColor، فایل gradle.properties)
- اضافه شدن Workflow ساخت خودکار APK در GitHub Actions
- چیدمان راست‌به‌چپ، مخفی‌شدن رمز عبور، کلید Back، اسکرول صفحات
- پیام‌های خطای فارسی و قابل‌فهم
- نمایش نام کاربر در داشبورد، مرتب‌سازی درخواست‌ها بدون نیاز به Index
- اپ اگر Storage فعال نباشد کرش نمی‌کند (فقط آپلود گواهی پزشکی خطا می‌دهد)
- آیکن اپ و فایل‌های Rules آماده (پوشه firebase-rules)

## ساختار Firestore
- `users/{uid}`: name, employeeCode, email
- `leaveBalances/{uid}`: entitlementDays, usedDays, incentiveDays, carriedDays (عدد)
- `leaveRequests/{id}`: userId, leaveType, startDate, endDate, hours, reason, medicalCertificateUrl, status, managerNote, createdAt
- `leaveTransactions/{id}`: userId, type, days, source, createdAt

## نکات مهم
- فایل `app/google-services.json` را باید از Firebase Console بگیرید (نام پکیج: `com.baharhooni.morkhesi`).
- Cloud Storage در Firebase نیاز به پلن Blaze دارد. بدون آن بقیه اپ کار می‌کند ولی آپلود گواهی پزشکی نه.
- خروجی این Workflow نسخه Debug است؛ برای نصب مستقیم روی گوشی مناسب است، نه انتشار در مارکت.
